package com.cibertec.edu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoadrunnerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
